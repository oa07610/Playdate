import React from 'react';
import RegistrationPage from './RegisterationPage'; // Import your component

function App() {
  return (
    <div className="App">
      <RegistrationPage />
      {/* Other components or content */}
    </div>
  );
}

export default App;
